import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  /**
   * signupForm created to stored username && password value
   */
  public signupForm = new FormGroup({
    userName: new FormControl("", [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/),]),
    password: new FormControl(null, [Validators.required, Validators.pattern(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{5,})/),]),
    confirmPassword: new FormControl("", [Validators.required]),
  })

  constructor(private services: DataService, private toastr: ToastrService, private router: Router) { }

  /**
   * The function checks if a form control is invalid and has been interacted with by the user.
   * @param {string} controlName - The controlName parameter is a string that represents the name of a
   * form control in the signupForm.
   * @returns a boolean value.
   */
  public checkIfControlvalid(controlName: string): any {
    return this.signupForm.get(controlName)?.invalid &&
      this.signupForm.get(controlName)?.errors &&
      (this.signupForm.get(controlName)?.dirty || this.signupForm.get(controlName)?.touched)
  }

  /**
   * The function "checkControlHasError" checks if a specific control in a signup form has a specific
   * error.
   * @param {string} controlName - The name of the form control you want to check for errors.
   * @param {string} error - The "error" parameter is a string that represents the specific error you
   * want to check for in the form control.
   * @returns the result of the expression `this.signupForm.get(controlName)?.hasError(error)`.
   */
  public checkControlHasError(controlName: string, error: string): any {
    return this.signupForm.get(controlName)?.hasError(error)

  }

  /**
   * The submitForm function checks if the confirmPassword and password fields in the signupForm are
   * the same, and if so, it sends a request to add the user data to the server and redirects to the
   * signin page. If the passwords do not match, it displays an error message.
   */
  public submitForm() {
    if (this.signupForm.get("confirmPassword")?.value === this.signupForm.get("password")?.value) {
      let user = {
        "userName": this.signupForm.get("userName")?.value,
        "password": this.signupForm.get("password")?.value,
        "confirmPassword": this.signupForm.get("confirmPassword")?.value,
      };
      this.services.addUserDataservice(user).subscribe((response: any) => {
        this.toastr.success("Signup successfully", "success");
        this.router.navigate(['/signin'])
      }, (error: any) => {
        this.toastr.error("eroor adding quote", "error")
      })
    }
    else {
      this.toastr.error("Confirm Password && Password must be Same", "error");
    }
  }
}
