import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PagenotfoundfordashboardComponent } from './pagenotfoundfordashboard.component';

describe('PagenotfoundfordashboardComponent', () => {
  let component: PagenotfoundfordashboardComponent;
  let fixture: ComponentFixture<PagenotfoundfordashboardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PagenotfoundfordashboardComponent]
    });
    fixture = TestBed.createComponent(PagenotfoundfordashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
