import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DataService } from '../../shared/services/data.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.scss']
})
export class DeleteModalComponent {
  @Input() quote: any;
  @Output() close = new EventEmitter();

  constructor(public http: HttpClient,
    public services: DataService,
    private toastr: ToastrService
  ) { }

  /**
   * The Delete function deletes a quote using a data service and displays a success message if the
   * deletion is successful, or an error message if there is an error.
   */
  public Delete(): void {
    this.services.deleteDataservice(this.quote).subscribe(() => {
      this.toastr.success("Quote Deleted successfully", "success")
      this.onClose();
    }, (error: any) => {
      this.toastr.error("eroor Deleted quote", "error")
    })
  }

  /**
   * The function "onClose" emits a "close" event.
   */
  public onClose(): void {
    this.close.emit();
  }
}
