import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent {

  /**
   *The code `public signForm = new FormGroup({ ... })` is creating an instance of the `FormGroup`
   *class from the `@angular/forms` module. This form group is used to manage the form controls for the
   *sign-in form.
   */
  public signForm = new FormGroup({
    userName: new FormControl("", [Validators.required]),
    password: new FormControl("", [Validators.required]),
  })


  constructor(private services: DataService, private toastr: ToastrService, private router: Router) { }

  /**
   * checkIfControlvalid in thi
   * @param controlName daynamic validate every with help controlName
   * @returns 
   */
  public checkIfControlvalid(controlName: string): any {
    return this.signForm.get(controlName)?.invalid &&
      this.signForm.get(controlName)?.errors &&
      (this.signForm.get(controlName)?.dirty || this.signForm.get(controlName)?.touched)
  }

  /**
   * checkControlHasError in this function check error and display
   * @param controlName daynamic validate every with help controlName
   * @param error get error from validator and display on screen
   * @returns 
   */
  public checkControlHasError(controlName: string, error: string): any {
    return this.signForm.get(controlName)?.hasError(error)
  }

  /**
   * on submit of form validate password && username
   */
  /**
   * The submitForm function checks if the entered username and password match any user in the
   * database, and if so, logs the user in and navigates to the dashboard.
   */
  submitForm() {
    let userName: any = this.signForm.get('userName')?.value;
    let password: any = this.signForm.get('password')?.value;

    this.services.getUserDataservice().subscribe((response: any[]) => {
      let checkUserName: any = false;
      let checkPassword: any = false;
      let userId: any = false;

      let users = response.findIndex((user): any => {
        if (user.userName.toLowerCase() == userName.toLowerCase()) {
          checkUserName = true;
          userId = user.id;
          if (user.password == password) {
            checkPassword = true
          }
        }
      })

      /* The code block is checking the values of `checkUserName` and `checkPassword` variables. */
      if (checkUserName == false) {
        this.toastr.error('Invalid Username', 'Error')
      }
      else if (checkPassword == false) {
        this.toastr.error('Invalid Password', 'Error')
      }
      else {
        users = 1;
      }

      if (users != -1) {
        localStorage.setItem("userName", userName?.toLowerCase());
        this.toastr.success('User logged in successsfully', 'Success')
        this.router.navigate(['/dashboard'])
      }
    }, () => {
      this.toastr.error('Error to Signin server error', 'Error')
    })
  }
}
