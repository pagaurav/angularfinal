import { Component } from '@angular/core';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss']
})
export class OperationComponent {
  public firstnumber: string = ""
  public secondnumber: string = ""
  public results: number = 0;
  public operationName: string = ""
  public showresult: boolean = false;
  
  /**
   * The function "displayOperation" sets the value of "results" to the given "result" parameter.
   * @param {number} result - The parameter "result" is a number that represents the result of an
   * operation.
   */
  displayOperation(result: number): void {
    this.results = result;
  }

  /**
   * The function "displayOperationName" sets the value of the "operationName" property.
   * @param {string} operationName - The parameter `operationName` is a string that represents the name
   * of an operation.
   */
  displayOperationName(operationName: string): void {
    this.operationName = operationName;
  }

  /**
   * The function "showResult" sets the value of "showresult" to a boolean value.
   * @param {boolean} result - stored final output
   */
  showResult(result: boolean): void {
    this.showresult = result;
  }
}
