import { Component } from '@angular/core';
import { DeleteModalComponent } from '../delete-modal/delete-modal.component';
import { AddEditQuoteComponent } from '../add-edit-quote/add-edit-quote.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productmanagement',
  templateUrl: './productmanagement.component.html',
  styleUrls: ['./productmanagement.component.scss']
})
export class ProductmanagementComponent {
  public quote: any[] = [];
  public totalCount: any = 0;
  public addEditQuoteModel !: BsModalRef;
  public deleteQuoteModel !: BsModalRef;

  /**
  * Constructor call and fetch value on render page
  * @param http with help http request fetch data
  * @param http with help http request POST data
  * @param services services labrary get dat and fetch
  */
  constructor(public http: HttpClient,
    public services: DataService,
    private modelServices: BsModalService,
    private toastr: ToastrService,
    private router: Router) {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    })
  }

  ngOnInit() {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    }, (error: any) => {
      this.toastr.error("eroor adding quote", "error")
    })
  }

  /**
   * The function "loadQuote" makes an HTTP request to a data service, retrieves a response, and
   * assigns the response to the "quote" variable.
   */
  private loadQuote(): void {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    }, (error: any) => {
      this.toastr.error("eroor adding quote", "error")
    })
  }

  /**
   * The function "openAddEditQuoteModal" opens a modal window for adding or editing a quote, and
   * updates the quote list when the modal is closed.
   */
  public openAddEditQuoteModal(quote: any = null): void {
    this.router.navigate(['/dashboard/addproduct'])
    // this.addEditQuoteModel = this.modelServices.show(AddEditQuoteComponent, {
    //   initialState: { quote: quote }, class: 'modal-lg',
    //   ignoreBackdropClick: true
    // });
    // this.addEditQuoteModel.content.close.subscribe(() => {
    //   this.addEditQuoteModel.hide();
    //   this.loadQuote();
    // })
  }

  /**
   * The function "deleteQuoteModal" opens a modal window to delete a quote and reloads the quote list
   * after the deletion.
   */
  public deleteQuoteModal(quote: any = null): void {
    this.deleteQuoteModel = this.modelServices.show(DeleteModalComponent, {
      initialState: { quote: quote }, class: 'modal-lg',
      ignoreBackdropClick: true
    });
    this.deleteQuoteModel.content.close.subscribe(() => {
      this.deleteQuoteModel.hide();
      this.loadQuote();
    })
  }
}
