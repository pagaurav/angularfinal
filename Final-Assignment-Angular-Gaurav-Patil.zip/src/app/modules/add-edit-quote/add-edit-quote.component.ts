import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-add-edit-quote',
  templateUrl: './add-edit-quote.component.html',
  styleUrls: ['./add-edit-quote.component.scss']
})
export class AddEditQuoteComponent {
  @Input() quote: any;
  @Output() close = new EventEmitter();

  constructor(public http: HttpClient,
    public services: DataService,
    private toastr: ToastrService
  ) { }

  /**
   * quoteForm form
   */
  public quoteForm = new FormGroup({
    authorName: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern('^[a-zA-Z \-\']+')]),
    quote: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(20)]),
    date: new FormControl("", [Validators.required]),
    gender: new FormControl("", [Validators.required]),
    quoteType: new FormControl("", [Validators.required])
  })


  /**
   * The ngOnInit function checks if there is a quote and updates the quoteForm with its values.
   */
  ngOnInit() {
    if (this.quote) {
      this.quoteForm.patchValue(this.quote);
    }
  }

  /**
   * The function checks if a form control is invalid and has errors, and if it has been modified or
   * touched.
   * @param {string} controlName - The controlName parameter is a string that represents the name of a
   * control in a form.
   * @returns a boolean value.
   */
  public checkIfControlvalid(controlName: string): any {
    return this.quoteForm.get(controlName)?.invalid &&
      this.quoteForm.get(controlName)?.errors &&
      (this.quoteForm.get(controlName)?.dirty || this.quoteForm.get(controlName)?.touched)
  }

  /**
   * The function checks if a specific control in a quote form has a specific error.
   * @param {string} controlName - The name of the form control you want to check for errors. This
   * should be a string value.
   * @returns the result of the `hasError` method called on the `quoteForm` control with the specified
   * `controlName` and `error` parameters.
   */
  public checkControlHasError(controlName: string, error: string): any {
    return this.quoteForm.get(controlName)?.hasError(error)
  }

  /**
   * The `save` function checks if a quote exists and either adds a new quote or updates an existing one
   * based on the payload.
   */
  public save(): void {
    let payload = this.assignvalueModel();
    if (!this.quote) {
      this.addQuote(payload);
    }
    else {
      this.updateQuote(payload);
    }
  }

  /**
   * The function "onClose" emits a "close" event.
   */
  public onClose(): void {
    this.close.emit();
  }

  /**
   * The addQuote function adds a quote by calling a service and displays a success message if
   * successful, or an error message if there is an error.
   * @param {any} payload - The payload parameter is an object that contains the data needed to add a
   * quote. It is passed as an argument to the addQuote function.
   */
  private addQuote(payload: any): void {
    this.services.addDataservice(payload).subscribe((response: any) => {
      this.toastr.success("Quote adding successfully", "success")
      this.onClose();
    }, (error: any) => {
      this.toastr.error("eroor adding quote", "error")
    })
  }

  /**
   * The function `updateQuote` updates a quote using a data service and displays a success message if
   * the update is successful, or an error message if there is an error.
   * @param {any} payload - The payload parameter is an object that contains the data needed to update
   * a quote. It is passed as an argument to the updateQuote function.
   */
  private updateQuote(payload: any): void {
    this.services.updateDataservice(payload).subscribe((response: any) => {
      this.toastr.success("Quote Updating successfully", "success")
      this.onClose();
    }, (error: any) => {
      this.toastr.error("eroor Updating quote", "error")
    })
  }

  /**
   * The function `assignvalueModel()` creates and returns an object with properties based on the values
   * of a form.
   * @returns an object with properties "id", "authorName", "quote", "date", "gender", and "quoteType".
   * The values of these properties are obtained from the corresponding form controls in the "quoteForm"
   */
  private assignvalueModel(): any {
    let quote = {
      "id": this.quote ? this.quote.id : 0,
      "authorName": this.quoteForm.get("authorName")?.value,
      "quote": this.quoteForm.get("quote")?.value,
      "date": this.quoteForm.get("date")?.value,
      "gender": this.quoteForm.get("gender")?.value,
      "quoteType": this.quoteForm.get("quoteType")?.value,
    };
    return quote;
  }
}
