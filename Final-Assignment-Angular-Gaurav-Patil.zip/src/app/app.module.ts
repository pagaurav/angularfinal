import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './modules/navbar/navbar.component';
import { SidebarComponent } from './modules/sidebar/sidebar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WelcomeComponent } from './modules/welcome/welcome.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxDatatableComponent } from './modules/ngx-datatable/ngx-datatable.component';
import { SigninComponent } from './modules/signin/signin.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FooterComponent } from './modules/footer/footer.component';
import { AddEditQuoteComponent } from './modules/add-edit-quote/add-edit-quote.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { DeleteModalComponent } from './modules/delete-modal/delete-modal.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { ButtoncontainerComponent } from './modules/buttoncontainer/buttoncontainer.component';
import { PagenotfoundComponent } from './modules/pagenotfound/pagenotfound.component';
import { PagenotfoundfordashboardComponent } from './modules/pagenotfoundfordashboard/pagenotfoundfordashboard.component';
import { SignupComponent } from './modules/signup/signup.component';
import { ProductmanagementComponent } from './modules/productmanagement/productmanagement.component';
import { AddproductComponent } from './addproduct/addproduct.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    WelcomeComponent,
    NgxDatatableComponent,
    SigninComponent,
    FooterComponent,
    AddEditQuoteComponent,
    DeleteModalComponent,
    DashboardComponent,
    ButtoncontainerComponent,
    PagenotfoundComponent,
    PagenotfoundfordashboardComponent,
    SignupComponent,
    ProductmanagementComponent,
    AddproductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxDatatableModule,
    FormsModule,
    ToastrModule.forRoot(),
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
