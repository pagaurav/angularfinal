import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})

export class AuthorizeService{
  constructor(){}

  /**
   * 
   * @returns returns true if username exists indicatig that user is logged in 
   */
  isLoggedIn(){
    return localStorage.getItem('userName') != null;
  }
  isLogOut(){
    (localStorage.getItem('userName') != null)
  }
}