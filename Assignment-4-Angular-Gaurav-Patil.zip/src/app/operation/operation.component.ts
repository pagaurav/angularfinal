import { Component } from '@angular/core';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss']
})
export class OperationComponent {
  public firstnumber: string = ""
  public secondnumber: string = ""
  public results : number = 0;
  public operationName : string = ""
  public showresult : boolean = false;

  displayOperation(result: number): void{
    this.results = result;
  }

  displayOperationName(operationName:string):void {
    this.operationName = operationName;
  }

  showResult(result:boolean) :void{
    this.showresult = result;
  }

  /**
   * Lifecycle Hooks 
   */
  ngOnChanges() {
    console.log(`ngOnChanges - data is ${this.showResult}`);
  }

  ngOnInit() {
    console.log(`ngOnInit  - data is ${this.showResult}`);
  }

  ngDoCheck() {
    console.log("Child component ngDoCheck")
  }

  ngAfterContentInit() {
    console.log("Child component ngAfterContentInit");
  }

  ngAfterContentChecked() {
    console.log("Child component ngAfterContentChecked");
  }

  ngAfterViewInit() {
    console.log("Child component ngAfterViewInit");
  }

  ngAfterViewChecked() {
    console.log("Child component ngAfterViewChecked");
  }

  ngOnDestroy() {
    console.log("Child component ngOnDestroy");
  }

}
