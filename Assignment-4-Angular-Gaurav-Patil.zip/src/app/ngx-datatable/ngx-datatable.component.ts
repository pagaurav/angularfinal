import { Component } from '@angular/core';
import { DataService } from '../data.service';
import { HttpClient } from '@angular/common/http';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal'
import { AddEditQuoteComponent } from '../add-edit-quote/add-edit-quote.component';
import { ToastrService } from 'ngx-toastr';
import { DeleteModalComponent } from '../delete-modal/delete-modal.component';

@Component({
  selector: 'app-ngx-datatable',
  templateUrl: './ngx-datatable.component.html',
  styleUrls: ['./ngx-datatable.component.scss']
})
export class NgxDatatableComponent {
  public quote: any[] = [];
  public totalCount : any = 0;
  public addEditQuoteModel !: BsModalRef;
  public deleteQuoteModel !: BsModalRef;

   /**
   * Constructor call and fetch value on render page
   * @param http with help http request fetch data
   * @param http with help http request POST data
   * @param services services labrary get dat and fetch
   */
   constructor(public http: HttpClient, 
    public services: DataService,
    private modelServices : BsModalService,
    private toastr: ToastrService) {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    })
  }

  ngOnInit() {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    },(error:any) => {
      this.toastr.error("eroor adding quote","error")
    })
  }

  private loadQuote () : void {
    this.services.getDataservice().subscribe((res: any) => {
      this.quote = res;
      this.totalCount = res.length;
    },(error:any) => {
      this.toastr.error("eroor adding quote","error")
    })
  }
  
  public openAddEditQuoteModal (quote : any = null):void {
    this.addEditQuoteModel = this.modelServices.show(AddEditQuoteComponent, {
      initialState: {quote : quote}, class:'modal-lg',
      ignoreBackdropClick: true
    });
    this.addEditQuoteModel.content.close.subscribe(() => {
      this.addEditQuoteModel.hide();
      this.loadQuote();
    })
  }

  public deleteQuoteModal (quote:any = null):void {
    this.deleteQuoteModel = this.modelServices.show(DeleteModalComponent,{
      initialState: {quote : quote}, class:'modal-lg',
      ignoreBackdropClick: true
    });
    this.deleteQuoteModel.content.close.subscribe(() => {
      this.deleteQuoteModel.hide();
      this.loadQuote();
    })
  }
  
}
