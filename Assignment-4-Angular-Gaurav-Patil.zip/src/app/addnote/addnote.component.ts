import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { first } from 'rxjs';
import { DataService } from '../data.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-addnote',
  templateUrl: './addnote.component.html',
  styleUrls: ['./addnote.component.scss']
})
export class AddnoteComponent {
  public inputtextarea = ""
  public authorName: any = "";
  data: any[] = [];

   /**
   * Constructor call and fetch value on render page
   * @param http with help http request fetch data
   * @param http with help http request POST data
   * @param services services labrary get dat and fetch
   */
   constructor(public http: HttpClient, public services: DataService ,private toastr: ToastrService) {
    this.services.getDataservice().subscribe((res: any) => {
      this.data = res;
    })
  }

  /**
   * in this function change text and stoded in input
   * @param value get values event target value
   */
  changetextareainput(value: string) {
    this.inputtextarea = value;
  }

  /**
   * onclick of button then change text to lower case on click
   */
  changelowercase() {
    this.inputtextarea = this.inputtextarea.toLocaleLowerCase();
    this.authorName = this.authorName.toLocaleLowerCase();
    this.toastr.success('Lowercase Sucessfull', 'Sucess');
  }

  /**
   * onclick of button then change text to Upper case on click
   */
  changeuppercase() {
    this.inputtextarea = this.inputtextarea.toUpperCase();
    this.authorName = this.authorName.toUpperCase();
    this.toastr.success('Uppercase Sucessfull', 'Sucess');
  }

  /**
   *  onclick of button then reset text
   */
  clear() {
    this.inputtextarea = '';
    this.authorName = "";
    this.toastr.warning('Clear Sucessfull', 'Sucess');
  }

  ngOnInit() {
    this.services.getDataservice().subscribe((res: any) => {
      this.data = res;
    })
  }
  
  /**
   * In this function save data to json server
   * http : with help http request POST data
   */
  async addData() {
    this.http.post('http://localhost:3000/quote', {
      quote: this.inputtextarea,
      author: this.authorName,
      date : new Date()
    }).pipe(first()).subscribe((data: any) => {
      this.services.getDataservice().subscribe((res: any) => {
        this.data = res;
        this.toastr.success('Data Save Sucessfull', 'Sucess');
        this.inputtextarea = '';
        this.authorName = "";
      })
    })
  }
}
