import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { MainscreenComponent } from './mainscreen/mainscreen.component';
import { AddnoteComponent } from './addnote/addnote.component';
import { NgxDatatableComponent } from './ngx-datatable/ngx-datatable.component';
import { SigninComponent } from './signin/signin.component';
import { PipesComponent } from './pipes/pipes.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {component:WelcomeComponent, path:''},
  {component:MainscreenComponent, path:'main'},
  {component:AddnoteComponent, path:'addnote'},
  {component:NgxDatatableComponent, path:'viewnote'},
  {component:SigninComponent, path:'signin'},
  {component:SignupComponent, path:'signup'},
  {component:PipesComponent, path:'pipe'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
