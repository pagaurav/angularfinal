import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../data.service';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-edit-quote',
  templateUrl: './add-edit-quote.component.html',
  styleUrls: ['./add-edit-quote.component.scss']
})
export class AddEditQuoteComponent {
  @Input() quote : any ;
  @Output() close = new EventEmitter();

  constructor(public http: HttpClient, 
    public services: DataService ,
    private toastr: ToastrService
    ){}

  public quoteForm = new FormGroup({
    authorName : new FormControl("", [Validators.required,Validators.maxLength(50),Validators.minLength(3),Validators.pattern('^[a-zA-Z \-\']+')]),
    quote : new FormControl("",[Validators.required,Validators.maxLength(50),Validators.minLength(20)]),
    date : new FormControl("",[Validators.required]),
    gender : new FormControl("",[Validators.required]),
    quoteType : new FormControl("",[Validators.required])
  })

  
  ngOnInit(){    
    if (this.quote) {
      this.quoteForm.patchValue(this.quote);
    }
  }

  public checkIfControlvalid (controlName:string): any {
    return this.quoteForm.get(controlName)?.invalid &&
    this.quoteForm.get(controlName)?.errors&&
    (this.quoteForm.get(controlName)?.dirty || this.quoteForm.get(controlName)?.touched )
  }

  public checkControlHasError (controlName:string , error:string): any {
    return this.quoteForm.get(controlName)?.hasError(error)
  }
  public save ():void {
    let payload = this.assignvalueModel();
    if (!this.quote) {
      this.addQuote(payload);
    }
    else{
      this.updateQuote(payload);
    }
  }

  public onClose() : void {
    this.close.emit();
  }

  private addQuote (payload:any):void {
    this.services.addDataservice(payload).subscribe((response:any) => {
      this.toastr.success("Quote adding successfully","success")
    this.onClose();
    },(error : any) => {
      this.toastr.error("eroor adding quote","error")
    })
  }

  private updateQuote(payload:any) :void {
    this.services.updateDataservice(payload).subscribe((response:any) => {
      this.toastr.success("Quote Updating successfully","success")
    this.onClose();
    },(error : any) => {
      this.toastr.error("eroor Updating quote","error")
    })
  }

  private assignvalueModel() :any {
    let quote = {
      "id" : this.quote ? this.quote.id : 0,
      "authorName" :  this.quoteForm.get("authorName")?.value,
      "quote" :  this.quoteForm.get("quote")?.value,
      "date" :  this.quoteForm.get("date")?.value,
      "gender" :  this.quoteForm.get("gender")?.value,
      "quoteType" :  this.quoteForm.get("quoteType")?.value,
    };
    return quote;
  }
}
