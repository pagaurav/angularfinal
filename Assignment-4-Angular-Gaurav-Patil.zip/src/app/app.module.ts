import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainscreenComponent } from './mainscreen/mainscreen.component';
import { OperationComponent } from './operation/operation.component';
import { ButtoncontainerComponent } from './buttoncontainer/buttoncontainer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WelcomeComponent } from './welcome/welcome.component';
import { AddnoteComponent } from './addnote/addnote.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxDatatableComponent } from './ngx-datatable/ngx-datatable.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PipesComponent } from './pipes/pipes.component';
import { FooterComponent } from './footer/footer.component';
import { AddEditQuoteComponent } from './add-edit-quote/add-edit-quote.component';
import {ModalModule} from 'ngx-bootstrap/modal';
import { DeleteModalComponent } from './delete-modal/delete-modal.component'

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    MainscreenComponent,
    OperationComponent,
    ButtoncontainerComponent,
    WelcomeComponent,
    AddnoteComponent,
    NgxDatatableComponent,
    SigninComponent,
    SignupComponent,
    PipesComponent,
    FooterComponent,
    AddEditQuoteComponent,
    DeleteModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxDatatableModule,
    FormsModule,
    ToastrModule.forRoot(),
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
