import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() sidenavStatus : boolean = false;
  
  /**
   * sidebarContent to add sidebar dynamic from json
   */
  sidebarContent = [
    {
      number : '1',
      name : 'home',
      routerLink : '/',
      icon : 'fa-solid fa-house'
    },
    {
      number : '2',
      name : 'operation',
      routerLink : '/main',
      icon : 'fa-solid fa-chart-line'
    },
    {
      number : '3',
      name : 'Add Note',
      routerLink : '/addnote',
      icon : 'fa-solid fa-box'
    },
    {
      number : '4',
      name : 'View Note',
      routerLink : '/viewnote',
      icon : 'fa-solid fa-cart-shopping'
    },
    {
      number : '5',
      name : 'pipe',
      routerLink : '/pipe',
      icon : 'fa-solid fa-eye'
    },
    {
      number : '6',
      name : 'setting',
      routerLink : '/setting',
      icon : 'fa-solid fa-gear'
    },
    {
      number : '7',
      name : 'about',
      routerLink : '/about',
      icon : 'fa-solid fa-circle-info'
    },
    {
      number : '8',
      name : 'contact',
      routerLink : '/contact',
      icon : 'fa-solid fa-phone'
    }  
  ]

}
