import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainscreen',
  templateUrl: './mainscreen.component.html',
  styleUrls: ['./mainscreen.component.scss']
})
export class MainscreenComponent implements OnInit {

  /**
   * Parent Lifecycle Hooks use
   */
  ngOnChanges() {
    console.log(`ngOnChanges - data is`);
  }

  public ngOnInit(): void {
    console.log(`ngOnInit `);
  }
  ngDoCheck() {
    console.log("parent ngDoCheck")
  }

  ngAfterContentInit() {
    console.log("parent ngAfterContentInit");
  }

  ngAfterContentChecked() {
    console.log("parent ngAfterContentChecked");
  }

  ngAfterViewInit() {
    console.log("parent ngAfterViewInit");
  }

  ngAfterViewChecked() {
    console.log("parent ngAfterViewChecked");
  }
}
